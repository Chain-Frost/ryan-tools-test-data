set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b    EG08_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_007.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_008.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_009.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_010.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_011.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_012.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG08_013.tcf
