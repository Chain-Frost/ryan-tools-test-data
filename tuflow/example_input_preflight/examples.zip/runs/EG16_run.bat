set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b	 -s1  Exg			  EG16_~s1~_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b	 -s1  D01			  EG16_~s1~_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  Exg  -s2  5m    EG16_~s1~_~s2~_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  D01  -s2  5m    EG16_~s1~_~s2~_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  Exg  -s2  2.5m  EG16_~s1~_~s2~_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  D01  -s2  2.5m  EG16_~s1~_~s2~_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  Exg  -s2  5m    EG16_~s1~_~s2~_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  D01  -s2  5m    EG16_~s1~_~s2~_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -e1  Q100			  EG16_~e1~_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -e1  QPMF			  EG16_~e1~_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -e1  Q100 -e2	2hr   EG16_~e1~_~e2~_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -e1  Q100 -e2	4hr	  EG16_~e1~_~e2~_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -e1  QPMF -e2	2hr	  EG16_~e1~_~e2~_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -e1  QPMF -e2	4hr	  EG16_~e1~_~e2~_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  Exg  -s2  5m  -e1  Q100 -e2  2hr  EG16_~s1~_~s2~_~e1~_~e2~_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  D01  -s2  5m  -e1  Q100 -e2  4hr	EG16_~s1~_~s2~_~e1~_~e2~_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  Exg  -s2  5m  -e1  QPMF -e2  2hr	EG16_~s1~_~s2~_~e1~_~e2~_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b  -s1  D01  -s2  5m  -e1  QPMF -e2  4hr	EG16_~s1~_~s2~_~e1~_~e2~_006.tcf
