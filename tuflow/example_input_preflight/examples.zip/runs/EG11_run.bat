@REM set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set "EXE_iSP=C:\TUFLOW\2025.2.1\TUFLOW_iSP_w64.exe"

start "TUFLOW" /wait   %EXE_iSP% -b    EG11_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b 	-e1 	Q100	 -e2	2hr		EG11_~e1~_~e2~_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b 	-e1 	QPMF	 -e2	2hr		EG11_~e1~_~e2~_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_007.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_008.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_009.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_010.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_011.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG11_012.tcf
