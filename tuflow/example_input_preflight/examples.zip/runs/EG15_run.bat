set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b    EG15_000.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_007.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_008.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_009.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG15_010.tcf
