set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b    EG12_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_007.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_008.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_009.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_010.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_011.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_012.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG12_013.tcf

