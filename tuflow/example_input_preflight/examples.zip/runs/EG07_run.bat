set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b    EG07_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_007.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_008.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_009.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_010.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_011.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG07_012.tcf
