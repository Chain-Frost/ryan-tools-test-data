@REM @echo off
setlocal
set "TUFLOW_EXE=C:\TUFLOW\2025.2.1\TUFLOW_iSP_w64.exe"

if not exist "%TUFLOW_EXE%" (
    echo ERROR: "%TUFLOW_EXE%" not found. Update Run_All_Examples.bat with the correct path.
    exit /b 1
)

pushd "%~dp0"
rem ----- Create_empties_run -----
@REM start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    Create_Empties

rem ----- EG04_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_006.tcf

rem ----- EG00_run -----

rem ----- EG01_run -----

rem ----- EG02_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_013.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_014.tcf

rem ----- EG03_run -----



rem ----- EG05_run -----

rem ----- EG06_run -----

rem ----- EG07_run -----

rem ----- EG08_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_012.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_013.tcf

rem ----- EG09_run -----

rem ----- EG10_run -----

rem ----- EG11_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_012.tcf

rem ----- EG12_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_012.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_013.tcf

rem ----- EG13_run -----

rem ----- EG14_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG14_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG14_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG14_003.tcf

rem ----- EG15_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_000.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_010.tcf

rem ----- EG16_run -----

rem ----- EG17_run -----

rem ----- EG18_run -----
popd
echo.
echo All TUFLOW example runs completed.
