set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP%   EG02_001.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_002.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_003.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_004.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_005.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_006.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_007.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_008.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_009.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_010.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_011.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_012.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_013.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_014.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_015.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_016.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_017.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_018.tcf
start "TUFLOW" /wait   %EXE_iSP%   EG02_019.tcf
