set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b    EG03_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_007.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_008.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_009.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_010.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_011.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_012.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_013.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_014.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG03_015.tcf
